<html lang="hu">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.1.3/dist/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
    <link rel="stylesheet" href="my.css">
    <title>Admin</title>
  </head>
  <body>
    <header>
        <a href="index.php"><img class="header-img" src="computer.png" alt="header_picture"></a>
    </header>
    <nav class="navbar">
        <ul class="nav-items">
            <li><a href="admin.php">Dolgozók</a></li>
            <li><a href="">Referenciák</a></li>
            <li><a href="">Rólunk</a></li>
            <li><a href="">Kapcsolat</a></li>
            <li><a href="index.php">Kijelentkezés</a></li>
        </ul>
    </nav>
    <section class="container2">
        <table>
          <tr>
            <th>Hámori Dávid</th>
            <th>Korom Rajmund</th>
          </tr>
          <tr>
            <th>Webfejlesztő</th>
            <th>Webfejlesztő</th>
          </tr>
        </table>
    </section>
    

    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.14.3/dist/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.1.3/dist/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>

    <footer>
        <p>Készítette: Hámori Dávid</p>
    </footer>
  </body>
</html>