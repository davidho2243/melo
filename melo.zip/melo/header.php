<html lang="hu">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.1.3/dist/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
    <link rel="stylesheet" href="my.css">
    <title>Basic weboldal</title>
  </head>
  <body>
    <header>
        <a href="index.php"><img class="header-img" src="computer.png" alt="header_picture"></a>
    </header>
    <nav class="navbar">
        <ul class="nav-items">
            <li><a href="login.php">Bejelentkezés</a></li>
            <li><a href="reg.php">Regisztráció</a></li>
            <li><a href="">Referenciák</a></li>
            <li><a href="">Rólunk</a></li>
            <li><a href="">Kapcsolat</a></li>
        </ul>
    </nav>
