<?php
error_reporting(E_ALL);

$dbName="login";
$dbUsername="root";
$dbPass="";
$serverName="localhost";

$connect=new mysqli($serverName, $dbUsername, $dbPass, $dbName);

if($connect->connect_error){
  die("Sikertelen kapcsolódás".$connect->connect_error);
}