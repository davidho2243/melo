<?php

function emptyInputReg($name, $email, $uid, $pass, $pass2, $worktype){
    $result;
    if(empty($name)|| empty($email) || empty($uid) || empty($pass) || empty($pass2)|| empty($worktype)){
        $result=true;
    }
    else{
        $result=false;
    }
    return $result;
}
function invalidUid($uid){
    $result;
    if(!preg_match("/^[a-zA-Z0-9]*$/",$uid)){
        $result=true;
    }
    else{
        $result=false;
    }
    return $result;
}
function invalidEmail($email){
    $result;
    if(!filter_var($email,FILTER_VALIDATE_EMAIL)){
        $result=true;
    }
    else{
        $result=false;
    }
    return $result;
}
function passMatch($pass, $pass2){
    $result;
    if($pass!==$pass2){
        $result=true;
    }
    else{
        $result=false;
    }
    return $result;
}

function usernameTaken($connect,$uid,$email){
    $sql="SELECT * FROM users WHERE userUid = ? OR userEmail=?;";
    $stmt= mysqli_stmt_init($connect);
    $result;
    if(!mysqli_stmt_prepare($stmt,$sql)){
        header("location: ../reg.php?error=stmterror");
        exit();
    }
    
        mysqli_stmt_bind_param($stmt, "ss", $uid, $email);
        mysqli_stmt_execute($stmt);

        $resultData=mysqli_stmt_get_result($stmt);
    
        if($row=mysqli_fetch_assoc($resultData)){
            return $row;
        }
        else{
            $result=false;
            return $result;
        }
        mysqli_stmt_close($stmt);
    return $result;
}

function createUser($connect,$name,$email, $uid, $pass,$worktype){
    $sql="INSERT INTO users(username, userEmail, userUid,userPwd, workType) VALUES (?,?,?,?,?);";
    $stmt= mysqli_stmt_init($connect);
    $result;
    if(!mysqli_stmt_prepare($stmt,$sql)){
        header("location: ../reg.php?error=stmterror");
        exit();
    }
        //jelszó titkosítása
        $hashedPass=password_hash($pass,PASSWORD_DEFAULT);

        mysqli_stmt_bind_param($stmt, "sssss",$name,$email, $uid, $hashedPass, $worktype);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_close($stmt);

        header("location: ../reg.php?error=none");
        exit();
    return $result;
}

function emptyInputLogin($username, $password){
    $result;
    if(empty($username)|| empty($password)){
        $result=true;
    }
    else{
        $result=false;
    }
    return $result;
}

function loginUser($connect,$username, $password){
    $uIdExists=usernameTaken($connect,$username,$username);

    if($uIdExists==false){
        
        header("location: ../login.php?error=wronglogin");
        exit();
    }
    $pwdHashed=$uIdExists["userPwd"];
    $checkPass=password_verify($password, $pwdHashed);

    if($checkPass==false){
        header("location: ../login.php?error=wronglogin");
        exit();
    }
    else if($checkPass==true){
        session_start();
        $_SESSION["userId"]=$uIdExists["userId"];
        $_SESSION["useruid"]=$uIdExists["userUid"];
        

    }
    header("location: ../admin.php");
    exit();
}
 