<?php

if(isset($_POST["submit"])){
    $name=$_POST["name"];
    $email=$_POST["email"];
    $uid=$_POST["fname"];
    $pass=$_POST["pass"];
    $pass2=$_POST["passrep"];
    $worktype=$_POST["worktype"];

    require_once 'dbh.inc.php';
    require_once 'functions.inc.php';

    if(emptyInputReg($name, $email, $uid, $pass, $pass2, $worktype)!==false){
        header("location: ../reg.php?error=emptyinput");
        exit();
    }
    if(invalidUid($uid)!==false){
        header("location: ../reg.php?error=invalidUid");
        exit();
    }
    if(invalidEmail($email)!==false){
        header("location: ../reg.php?error=invalidemail");
        exit();
    }
    if(passMatch($pass, $pass2)!==false){
        header("location: ../reg.php?error=passwordnotmatch");
        exit();
    }
    if(usernameTaken($connect, $uid)!==false){
        header("location: ../reg.php?error=usernametaken");
        exit();
    }

    createUser($connect, $name, $email, $uid, $pass, $worktype);

}
    
    else{
        header("location: ../reg.php");
        exit();
    }
