var admin=document.getElementById("loginBtn");

admin.addEventListener("click",function(){
    window.location.href = "admin.php";
})