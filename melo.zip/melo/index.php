<?php
include_once 'header.php';
?>

<section class="container">
        <h1>weboldal leírása:</h1><br>
        <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Possimus repellendus praesentium at perspiciatis ratione nostrum officiis, voluptate cum doloribus rem nobis cumque id. Enim sapiente tenetur soluta, aut fugit fuga?</p>
    </section>
    
 <?php
 include_once 'footer.php';
 ?>   
