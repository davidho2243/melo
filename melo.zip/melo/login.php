<?php
include_once 'header.php';
?>
    <?php
      
      
      if(isset($_POST['fname'])&& isset($_POST['pass'])){
        $username=$_POST['fname'];
        $password=$_POST['pass'];

        $sql = "SELECT * FROM bejelentkezési_adatok WHERE userName = '$username' AND passWord = '$password'";
        $result=$connect->query($sql);

        if($result->num_rows==1){
          echo "<p>Sikeres bejelentkezés</p>";

          echo "<script src=index.js></script>";
        }
        else{
          echo "Hibás felhasználónév vagy jelszó!";
        }
      }
    ?>

    <section class="login">
        <form action="includes/login.inc.php" method="post">
            <h2 class="login-h2">Bejelentkezés</h2>
            <label for="fname">Felhasználónév:</label><br>
            <input type="text" id="fname" name="fname"><br><br>
            <label for="pass">Jelszó:</label><br>
            <input type="password" id="pass" name="pass"><br><br>
            <button type="submit" name="submit">Bejelentkezés</button>
        <?php
         if(isset($_GET["error"])){
            if($_GET["error"]=="emptyinput"){
            echo "<p>Tölts ki minden mezőt!</p>";
        }

       else if($_GET["error"]=="invalidUid"){
            echo "<p>Hibás felhasználónév!</p>";
        }

       else if($_GET["error"]=="invalidEmail"){
            echo "<p>Hibás E-mail cím!</p>";
        }

       else if($_GET["error"]=="passwordnotmatch"){
            echo "<p>A két jelszó nem egyezik!</p>";
        }
      }
       ?>     
    
        </form>
    <?php
      include_once 'footer.php';
    ?>
