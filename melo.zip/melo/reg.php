<?php
include_once 'header.php';
?>

<section class="registration-form">
        <h2>Regisztráció</h1><br>
        <form action="includes/reg.inc.php" method="post">
            <label for="name">Teljes név:</label><br>
            <input type="text" name="name" id="name" placeholder="Teljes név..."><br><br>
            <label for="email">Email:</label><br>
            <input type="email" name="email" id="email" placeholder="E-mail..."><br><br>
            <label for="fname">Felhasználónév:</label><br>
            <input type="text" id="fname" name="fname" placeholder="Felhasználónév...."><br><br>
            <label for="pass">Jelszó:</label><br>
            <input type="password" id="pass" name="pass" placeholder="Jelszó..."><br><br>
            <label for="passrep">Jelszó mégegyszer:</label><br>
            <input type="password" id="passrep" name="passrep" placeholder="Jelszó..."><br><br>
            <label for="worktype">Munka jellege:</label><br>
            <input type="text" id="worktype" name="worktype" placeholder="Munka típusa..."><br><br>
            <button type="submit" name="submit">Regisztráció</button>
        </form>
        <?php
    if(isset($_GET["error"])){

        if($_GET["error"]=="emptyinput"){
            echo "<p>Tölts ki minden mezőt!</p>";
        }

       else if($_GET["error"]=="invalidUid"){
            echo "<p>Hibás felhasználónév!</p>";
        }

       else if($_GET["error"]=="invalidEmail"){
            echo "<p>Hibás E-mail cím!</p>";
        }

       else if($_GET["error"]=="passwordnotmatch"){
            echo "<p>A két jelszó nem egyezik!</p>";
        }
            
    }
?>
</section>


    
 <?php
 include_once 'footer.php';
 ?>   
